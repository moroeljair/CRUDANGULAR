import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Gasto} from '../models/gasto';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GastoService {

  selectedGasto: Gasto;
  gastos: Gasto[] = [];

  constructor(private http: HttpClient) { 
    this.selectedGasto=new Gasto();
  }

  //conexion con express
  //obtener consultas
  getGastos(){
    return this.http.get('http://localhost:3000/api/gastos');
  }

  //metodo POST
  readonly URL_API='http://localhost:3000/api/gastos';

  postGasto(Gasto: Gasto){
    return this.http.post(this.URL_API, Gasto);
  } 

  //PUT
  putGasto(gasto: Gasto, _id:string){
    return this.http.put(this.URL_API+'/'+_id,gasto);
  }

  //obtener gasto
  obtenerGasto(_id:string){
    return this.http.get(this.URL_API+'/'+_id); 
  }

  //DELETE
  deleteGasto(_id:string){
    return this.http.delete(this.URL_API+'/'+_id);
  }


}
