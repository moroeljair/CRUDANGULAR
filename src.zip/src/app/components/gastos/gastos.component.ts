import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Gasto } from 'src/app/models/gasto';
import { GastoService } from 'src/app/services/gasto.service';

@Component({
  selector: 'app-gastos',
  templateUrl: './gastos.component.html',
  styleUrls: ['./gastos.component.css']
})
export class GastosComponent implements OnInit {

  gastos: Gasto[] = [];
  titulo = 'Registrar gasto';
  _id: string | null;
  
  constructor(public gastoService: GastoService,
    private aRouter: ActivatedRoute) { 
      this._id = this.aRouter.snapshot.paramMap.get('_id');
      console.log(this._id);
  }

  ngOnInit(): void {
    this.getGastos();
    
  }

  resetForm(form?:NgForm)
  {
    if(form)
    {
      form.reset();
      this.gastoService.selectedGasto=new Gasto();
    }
  }

  addGasto(form:NgForm)
  {
    this.gastoService.postGasto(form.value)
    .subscribe(res=>{
      console.log(res);
      this.resetForm(form);
      this.getGastos();
    })
  }

  editGastoPut(form:NgForm){
    if(this._id != null){
      this.gastoService.putGasto(form.value,this._id).subscribe(res =>{
        console.log(res);
        this.getGastos();
      })
    }
  }

  getGastos()
  {
    this.gastoService.getGastos()
    .subscribe(res=>{
      this.gastoService.gastos=res as Gasto[];
      console.log(res);
    })
  }

  deleteGasto(id: any){
    console.log(id);
    this.gastoService.deleteGasto(id).subscribe(res=> {
      console.log(res);
      this.getGastos();
    })
  }

  editGasto(id: any){
    console.log(id);
    this._id=id;
    this.gastoService.obtenerGasto(id).subscribe(data=>{
      this.gastoService.selectedGasto=data as Gasto;
    })
  }  
}
